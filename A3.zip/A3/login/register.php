<?php
// register.php
include '../db_config.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // ユーザー名の重複チェック
    $check_user_query = "SELECT id FROM users WHERE username = ?";
    $stmt = $conn2->prepare($check_user_query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $message = "<div class='error-message'>エラー: ユーザー名は既に存在します。</div>";
        $stmt->close();
    } else {
        $stmt->close();

        // ユーザーをデータベースに挿入
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        $stmt = $conn2->prepare($sql);
        $stmt->bind_param("ss", $username, $password);

        if ($stmt->execute()) {
            $message = "<div class='success-message'>ユーザーが正常に登録されました。<a href='login.php'>ログイン</a></div>";
        } else {
            $message = "<div class='error-message'>エラー: " . $sql . "<br>" . $conn2->error . "</div>";
        }

        $stmt->close();
    }
}

?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>ユーザー登録</title>
    <style>
        .A {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('W.png');
            background-size: cover;
            background-repeat: no-repeat;
            font-family: Arial, sans-serif;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: none;
            color: #fff;
            background-color: #007BFF;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .additional-info {
            margin-top: 10px;
            text-align: center;
        }
        .additional-info a {
            color: #007BFF;
            text-decoration: none;
        }
        .additional-info a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="A">
    <?php echo $message; ?>
    <form method="POST" action="register.php">
        <input type="text" name="username" placeholder="ユーザー名" required><br>
        <input type="password" name="password" placeholder="パスワード" required><br>
        <input type="submit" value="登録">
        <div class="additional-info">
            <a href="login.php">ログインはこちら</a>
        </div>
    </form>
    </div>
</body>
</html>
