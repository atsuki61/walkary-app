async function save_distance2() {
    const walkedData = JSON.parse(localStorage.getItem('walked_data')) || [];
    const weight = localStorage.getItem('userweight');
    const distance = JSON.parse(localStorage.getItem('walked_distance'));
    const today = new Date().toISOString().split('T')[0];

    // 体重が存在しない場合はエラーメッセージを表示
    if (weight === null) {
        console.error("体重データが取得できません。");
        return;
    }

    // 距離が存在しない場合はエラーメッセージを表示
    if (distance === null) {
        console.error("距離データが取得できません。");
        return;
    }

    // 今日のデータを更新または追加
    const existingEntryIndex = walkedData.findIndex(item => item.date === today);
    if (existingEntryIndex > -1) {
        // 既存のデータがある場合は更新
        walkedData[existingEntryIndex].distance += distance; // 距離を加算
    } else {
        // 新しいデータを追加
        walkedData.push({
            date: today,
            distance: distance,
            weight: weight,
        });
    }

    // 14日より古いデータを削除
    const recentWalkedData = walkedData.filter(item => {
        const itemDate = new Date(item.date);
        const todayDate = new Date(today);
        const diffDays = Math.floor((todayDate - itemDate) / (1000 * 60 * 60 * 24));
        return diffDays < 7; // 7日以内のデータを残す
    });

    // データをローカルストレージに保存
    localStorage.setItem('walked_data', JSON.stringify(recentWalkedData));

    // 消費カロリーを計算して保存
    calculateAndSaveCalories(recentWalkedData);
}

function calculateAndSaveCalories(walkedData) {
    const caloriesData = [];
    const METS_WALKING = 3.0; // 歩行時のMETS
    const METS_RUNNING = 11.0; // 走行時のMETS

    walkedData.forEach(item => {
        const walkingCalories = METS_WALKING * ((item.distance / 1.34) / 60) * item.weight; // メッツ＊時間(h)＊体重(kg)
        const runningCalories = METS_RUNNING * ((item.distance / 2.5) / 60) * item.weight; // メッツ＊時間(h)＊体重(kg)

        caloriesData.push({
            date: item.date,
            walking: walkingCalories,
            running: runningCalories
        });
    });

    // 14日より古いカロリーデータを削除
    const existingCaloriesData = JSON.parse(localStorage.getItem('calories_data')) || [];
    const recentCaloriesData = existingCaloriesData.filter(item => {
        const itemDate = new Date(item.date);
        const todayDate = new Date();
        const diffDays = Math.floor((todayDate - itemDate) / (1000 * 60 * 60 * 24));
        return diffDays < 7; // 7日以内のデータを残す
    });

    // 新しいカロリーデータを追加
    recentCaloriesData.push(...caloriesData);
    localStorage.setItem('calories_data', JSON.stringify(recentCaloriesData));
}
