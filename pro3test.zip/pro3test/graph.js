async function saveData() {
    const walkedData = JSON.parse(localStorage.getItem('walked_data')) || [];
    const today = new Date().toISOString().split('T')[0];

    // Djangoから体重を取得
    const weight = await fetchWeightFromDjango();
    // Djangoから距離を取得
    const distance = await fetchDistanceFromDjango();

    // 体重が存在しない場合はエラーメッセージを表示
    if (weight === null) {
        console.error("体重データがDjangoから取得できません。");
        return;
    }

    // 距離が存在しない場合はエラーメッセージを表示
    if (distance === null) {
        console.error("距離データがDjangoから取得できません。");
        return;
    }

    // 既存データに今日のデータを追加
    walkedData.push({
        date: today,
        distance: distance,
        weight: weight,
    });

    // 14日より古いデータを削除
    const recentWalkedData = walkedData.filter(item => {
        const itemDate = new Date(item.date);
        const todayDate = new Date(today);
        const diffDays = Math.floor((todayDate - itemDate) / (1000 * 60 * 60 * 24));
        return diffDays < 14; // 14日以内のデータを残す
    });

    // データをローカルストレージに保存
    localStorage.setItem('walked_data', JSON.stringify(recentWalkedData));

    // 消費カロリーを計算して保存
    calculateAndSaveCalories(recentWalkedData);
}

async function fetchWeightFromDjango() {
    try {
        const response = await fetch('/api/user_profile/'); // ユーザープロファイルのエンドポイント
        const data = await response.json();
        return data.weight; // 体重を返す
    } catch (error) {
        console.error("体重の取得に失敗しました:", error);
        return null;
    }
}

async function fetchDistanceFromDjango() {
    try {
        const response = await fetch('/api/walkary_steps/'); // 歩数データのエンドポイント
        const data = await response.json();
        return data.steps; // 距離を返す（必要に応じて適切にデータを処理）
    } catch (error) {
        console.error("距離の取得に失敗しました:", error);
        return null;
    }
}

function calculateAndSaveCalories(walkedData) {
    const caloriesData = [];
    const METS_WALKING = 3.0; // 歩行時のMETS
    const METS_RUNNING = 11.0; // 走行時のMETS

    walkedData.forEach(item => {
        const walkingCalories = METS_WALKING * ((item.distance / 1.34) / 60) * item.weight; // メッツ＊時間(h)＊体重(kg)
        const runningCalories = METS_RUNNING * ((item.distance / 2.5) / 60) * item.weight; // メッツ＊時間(h)＊体重(kg)

        caloriesData.push({
            date: item.date,
            walking: walkingCalories,
            running: runningCalories
        });
    });

    // 14日より古いカロリーデータを削除
    const existingCaloriesData = JSON.parse(localStorage.getItem('calories_data')) || [];
    const recentCaloriesData = existingCaloriesData.filter(item => {
        const itemDate = new Date(item.date);
        const todayDate = new Date();
        const diffDays = Math.floor((todayDate - itemDate) / (1000 * 60 * 60 * 24));
        return diffDays < 14; // 14日以内のデータを残す
    });

    // 新しいカロリーデータを追加
    recentCaloriesData.push(...caloriesData);
    localStorage.setItem('calories_data', JSON.stringify(recentCaloriesData));
}
