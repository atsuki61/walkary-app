async function save_distance2() {
    const walkedData = JSON.parse(localStorage.getItem('walked_data')) || [];
    const weight1 = localStorage.getItem('userweight'); // 体重を数値に変換 
    const distance = parseFloat(localStorage.getItem('walked_distance')); // 距離を数値に変換
    const now = new Date();
    const year = now.getFullYear(); 
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const today = `${year}-${month}-${day}`;
    const weight = parseFloat(weight1);
    
    // 体重が存在しない場合はエラーメッセージを表示
    if (isNaN(weight)) {
        console.error("体重データが取得できません。");
        return;
    }

    // 距離が存在しない場合はエラーメッセージを表示
    if (isNaN(distance)) {
        console.error("距離データが取得できません。");
        return;
    }

    // 今日のデータを更新または追加
    const existingEntryIndex = walkedData.findIndex(item => item.date === today);
    if (existingEntryIndex > -1) {
        // 既存のデータがある場合は更新
        walkedData[existingEntryIndex].distance += distance; // 距離を加算
    } else {
        // 新しいデータを追加
        walkedData.push({
            date: today,
            distance: distance,
            weight: weight,
        });
    }

    // 7回より古いデータを削除
    if (walkedData.length > 7) {
        walkedData.splice(0, walkedData.length - 7); // 最初のデータを削除
    }

    // データをローカルストレージに保存
    localStorage.setItem('walked_data', JSON.stringify(walkedData));

    // 消費カロリーを計算して保存
    calculateAndSaveCalories(walkedData);
}

function calculateAndSaveCalories(walkedData) {
    const caloriesData = [];
    const METS_WALKING = 3.0; // 歩行時のMETS
    const METS_RUNNING = 11.0; // 走行時のMETS

    walkedData.forEach(item => {
        const walkingCalories = METS_WALKING * (item.distance/4) * item.weight; // メッツ＊時間(h)＊体重(kg)
        const runningCalories = METS_RUNNING * (item.distance/4) * item.weight; // メッツ＊時間(h)＊体重(kg)

        // デバッグ用の出力
        console.log(`距離: ${item.distance}, 体重: ${item.weight}, 歩行カロリー: ${walkingCalories}&${runningCalories}`);
        console.log(item.date);
        
        caloriesData.push({
            date: item.date,
            walking: walkingCalories,
            running: runningCalories
        });
    });

    // 既存のカロリーデータを取得
    const existingCaloriesData = JSON.parse(localStorage.getItem('calories_data')) || [];
    
    // 新しいカロリーデータを更新または追加
    caloriesData.forEach(newCalories => {
        const existingCaloriesIndex = existingCaloriesData.findIndex(item => item.date === newCalories.date);
        if (existingCaloriesIndex > -1) {
            // 既存のカロリーデータがある場合は更新
            existingCaloriesData[existingCaloriesIndex].walking += (newCalories.walking-existingCaloriesData[existingCaloriesIndex].walking);
            existingCaloriesData[existingCaloriesIndex].running += (newCalories.running-existingCaloriesData[existingCaloriesIndex].running);
        } else {
            // 新しいカロリーデータを追加
            existingCaloriesData.push(newCalories);
        }
    });

    // 7回より古いカロリーデータを削除
    if (existingCaloriesData.length > 7) {
        existingCaloriesData.splice(0, existingCaloriesData.length - 7); // 最初のデータを削除
    }

    // 新しいカロリーデータを保存
    localStorage.setItem('calories_data', JSON.stringify(existingCaloriesData));

    console.log('保存されたカロリーデータ:', existingCaloriesData);
}
