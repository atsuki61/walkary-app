<?php
// index.php
include '../db_config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Walkary</title>
    <link rel="stylesheet" href="../index.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>マイページ</h1>
        </header>
        <main>
            <section>
                <h2>ユーザー情報</h2>
                <p>名前:<?php try {
    $pdo = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // SQLクエリを準備
    $stmt = $pdo->prepare("SELECT username FROM users WHERE id = :user_id");
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    // クエリを実行
    $stmt->execute();

    // 結果を取得し、表示
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo $row['username'];
    }
} catch (PDOException $e) {
    echo "データベース接続失敗: " . $e->getMessage();
}

// 接続を閉じる
$pdo = null;?></p>
            </section>
            <section>
                <h2>お問い合わせフォーム</h2>
                <form method="post" action="send_mail.php">
  <label for="name">名前:</label>
  <input type="text" id="name" name="name" required>

  <label for="email">メールアドレス:</label>
  <input type="email" id="email" name="email" required>

  <label for="subject">件名:</label>
  <input type="text" id="subject" name="subject" required>

  <label for="message">メッセージ:</label>
  <textarea id="message" name="message" required></textarea>

  <input type="submit" value="送信">
</form>
            </section>
        </main>
        <nav>
            <ul>
                <li><a href="../graph/graph.php">グラフ</a></li>
                <li><a href="../home/home.php">ホーム</a></li>
                <li><a href="../map/map.php">マップ</a></li>
                <li><a href="mypage.php" class="active">マイページ</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>
