<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];

    $to = "st062203@m01.kyoto-kcg.ac.jp"; // 送信先のメールアドレス
    $headers = "From: " . $email;

    if (mail($to, $subject, $message, $headers)) {
        echo "メールの送信に成功しました。";
    } else {
        echo "メールの送信に失敗しました。";
        header("Location: mypage.php");
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>送信</title>
</head>
<body>
<a href="mypage.php">戻る</a>
</body>
</html>