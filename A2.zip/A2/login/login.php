<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// login.php
include '../db_config.php';
session_start();

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT id, password FROM users WHERE username = ?";
    $stmt = $conn2->prepare($sql);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $hashed_password);

    if ($stmt->num_rows > 0) {
        $stmt->fetch();
        if (password_verify($password, $hashed_password)) {
            $_SESSION['user_id'] = $id;
            header("Location: ../home/home.php");
            exit();
        } else {
            $message = "<div class='error-message'>パスワードが間違っています。</div>";
        }
    } else {
        $message = "<div class='error-message'>ユーザー名が存在しません。</div>";
    }

    $stmt->close();
}

$conn2->close();
?>

<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>ログイン</title>
    <style>
        .AA {
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .A {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 300px;
            height: 1000px;
            padding-left: 300px;
            padding-right: 300px;
            background-image: url('W.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            font-family: Arial, sans-serif;
        }
        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px 0px rgba(0,0,0,0.1);
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: none;
            color: #fff;
            background-color: #007BFF;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        .additional-info {
            margin-top: 10px;
            text-align: center;
        }
        .additional-info a {
            color: #007BFF;
            text-decoration: none;
        }
        .additional-info a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="AA">
    <div class="A">
    <?php echo $message; ?>
    <form method="POST" action="login.php">
        <input type="text" name="username" placeholder="ユーザー名" required><br>
        <input type="password" name="password" placeholder="パスワード" required><br>
        <input type="submit" value="ログイン">
        <div class="additional-info">
            登録はまだですか? <a href="register.php">アカウントを作成</a>
        </div>
    </form>
    </div>
    </div>
</body>
</html>

