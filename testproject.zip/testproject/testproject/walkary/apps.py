from django.apps import AppConfig


class WalkaryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'walkary'
