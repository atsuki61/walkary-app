"""2024/11/25 金定歩夢 django移行"""
from django.apps import AppConfig


class WalkaryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'walkary'
