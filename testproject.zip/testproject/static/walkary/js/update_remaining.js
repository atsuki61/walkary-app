document.addEventListener("DOMContentLoaded", () => {
    const goalElement = document.getElementById("target-goal");
    const goal = parseInt(goalElement.innerText, 10);

    const walkedData = JSON.parse(localStorage.getItem("walked_data")) || [];
    const latestEntry = walkedData[walkedData.length - 1];
    const walkedDistance = latestEntry?.steps || 0; // 最新のstepsを取得、undefinedの場合は0

    const remainingDistance = Math.max(goal - walkedDistance, 0);
    const remainingElement = document.getElementById("remaining");
    remainingElement.innerText = `${remainingDistance} m`;

    window.addEventListener("storage", (event) => {
        if (event.key === "walked_data") {
            const newWalkedData = JSON.parse(event.newValue) || [];
            const newLatestEntry = newWalkedData[newWalkedData.length - 1];
            const newWalkedDistance = newLatestEntry?.steps || 0;

            const newRemainingDistance = Math.max(goal - newWalkedDistance, 0);
            remainingElement.innerText = `${newRemainingDistance} m`;
        }
    });
});
