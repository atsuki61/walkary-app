document.addEventListener("DOMContentLoaded", () => {
    // 定数定義
    const CIRCUMFERENCE = 283; // SVG円周の基本値

    // 主要DOM要素の取得
    const goalElement = document.getElementById("target-goal");
    const remainingElement = document.getElementById("remaining");
    const progressElement = document.querySelector(".progress");

    // 目標値の取得
    const goal = parseInt(goalElement.innerText, 10);

    // 進捗更新共通処理
    const updateProgress = (walked) => {
        // 残り距離計算＆表示更新
        const remaining = Math.max(goal - walked, 0);
        remainingElement.textContent = `${remaining.toFixed(0)} m`;

        // プログレスバー更新
        const percentage = (walked / goal) * 100;
        progressElement.style.strokeDashoffset = CIRCUMFERENCE - (CIRCUMFERENCE * percentage) / 100;
    };

    // ローカルストレージから初期値を取得
    const initialWalked = JSON.parse(localStorage.getItem("walked_distance")) || 0;
    updateProgress(initialWalked);

    // ストレージ変更監視
    window.addEventListener("storage", (event) => {
        if (event.key === "walked_distance") {
            const newWalked = JSON.parse(event.newValue) || 0;
            updateProgress(newWalked);
        }
    });
});