document.addEventListener("DOMContentLoaded", () => {
    const weight = JSON.parse(localStorage.getItem("userWeight")) || 0;
    let walkedDistance = JSON.parse(localStorage.getItem("walked_data")) || 0;

    const calculateWalkingKcal = Math.max(weight * (walkedDistance[walkedDistance.length-1].steps/1000) * 1.05, 0);

    const calculateRunningKcal = Math.max(weight * (walkedDistance[walkedDistance.length-1].steps/1000) * 1.25, 0);

    const updateKcalDisplay = () => {

        document.getElementById('walk-kcal').innerText = `${calculateWalkingKcal.toFixed(2)} kcal`;
        document.getElementById('run-kcal').innerText = `${calculateRunningKcal.toFixed(2)} kcal`;
    };

    updateKcalDisplay();

    window.addEventListener("storage", (event) => {
        if (event.key === "walked_distance") {
            walkedDistance = JSON.parse(event.newValue) || 0;
            updateKcalDisplay();
        }
    });
});
