2024/11/25 金定歩夢
python 3.11.2

python manage.py runserver
